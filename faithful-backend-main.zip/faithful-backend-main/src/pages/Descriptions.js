import React from 'react';

const BillsPaidDesc = ({ match }) => (
    <div>
      <p>Determining from which source of income to pay your bills and when to pay each bill is helpful to make shure each bill can be paid. YOu may want to payy utilities form the first paycheck of the month and the mortgage or rent for the next month from the second paycheck of the month. </p>
    </div>
  );

export default BillsPaidDesc;