import React from 'react';

const MillionPlan = ({ match }) => (
    <div>
      <h2>Million Dollar Plan</h2>
    </div>
  );

export default MillionPlan;