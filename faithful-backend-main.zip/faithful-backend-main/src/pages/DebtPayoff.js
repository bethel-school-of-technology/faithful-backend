import React from 'react';

const DebtPayoff = ({ match }) => (
    <div>
      <h2>Debt Payoff</h2>
    </div>
  );

export default DebtPayoff;