import React from 'react';
import SowReap from './SowReap';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

const CashFlowDaily = ({ match }) => (
    <div>
      <h2>Cash Flow Daily</h2>
    </div>
  );

export default CashFlowDaily;
