import React from 'react';

const BillsPaid = ({ match }) => (
    <div>
      <h2>Determine Source for Each Bill</h2>
      <h2>Schedule of When to Pay Bills</h2>
    </div>
  );

export default BillsPaid;