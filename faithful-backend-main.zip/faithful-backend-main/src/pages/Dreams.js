import React from 'react';

const Dreams = ({ match }) => (
    <div>
      <h2>Dreams and Visions</h2>
    </div>
  );

export default Dreams;