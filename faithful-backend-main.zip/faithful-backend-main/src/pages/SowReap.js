import React from 'react';

const SowReap = ({ match }) => (
    <div>
      <h2>Sowing And Reaping</h2>
    </div>
  );

export default SowReap;
