import React from 'react';

const CashFlowMaking = () => (
  <div>
    <h2>Determining Cash Flow</h2>
  </div>
);

export default CashFlowMaking;
