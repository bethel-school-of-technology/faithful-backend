import React from 'react';

const Attitudes = ({ match }) => (
    <div>
      <h2>Attitudes Toward Money</h2>
    </div>
  );

export default Attitudes;