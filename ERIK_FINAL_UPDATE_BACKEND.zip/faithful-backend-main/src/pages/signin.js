import React from 'react';

const SignIn = ({ match }) => (
    <div>
      <h2>Sign In</h2>
    </div>
  );

export default SignIn;