import React from 'react';

const SignUp = ({ match }) => (
    <div>
      <h2>Sign Up</h2>
    </div>
  );

export default SignUp;