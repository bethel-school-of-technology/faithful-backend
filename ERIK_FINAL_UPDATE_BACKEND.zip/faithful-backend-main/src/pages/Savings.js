import React from 'react';

const Savings = ({ match }) => (
    <div>
      <h2>Savings</h2>
    </div>
  );

export default Savings;